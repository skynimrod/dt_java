using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpJExcel.Interop
	{
	interface Format
		{
		}
	}
